package �����ڹ�������Ʈ;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


class User {
	private String id;
	private String pwd;
	
	public User(String id, String pwd) {
		this.id = id;
		this.pwd = pwd;
	}
	
	public String getId() {
		return id;
	}
	
	public String getPwd() {
		return pwd;
	}
}

//=================�α��� â=============================
class LoginWindow extends JFrame {
	
	JButton login;
	JTextField id;
	JPasswordField pwd;
	Test test;
	
	Vector<User> v = new Vector<>();

	public LoginWindow(Test test)
	{
		this.test = test;
		setLayout(null);

		add(new JLabel("ID :  "));
		add(id = new JTextField(20));
		add(new JLabel("PW :  "));
		add(pwd = new JPasswordField(20));

		login = new JButton("�α���");
		add(login);

		login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(id.getText().equals("admin") && pwd.getText().equals("1234")) {
					JOptionPane.showMessageDialog(null, "�α��� ����!");
				}
				else {
					JOptionPane.showMessageDialog(null, "�α��� ����!");
				}
			}
		});

		setLocationRelativeTo(null);
		setVisible(true);
	}
}

class SignWindow extends JFrame {
	JTextField name, age, phone, birth, etc;
	JComboBox sex;
	String []sexlist = {"����", "����"};
	JButton signup;
	Test test;
	
	public SignWindow(Test test) {
		setLayout(null);
		this.test = test;
		add(new JLabel("�̸�   "));
		add(name = new JTextField(20));
		add(new JLabel("����   "));
		add(age = new JTextField(20));
		add(new JLabel("����  "));
		add(sex = new JComboBox(sexlist));
		add(new JLabel("��ȭ��ȣ  "));
		add(phone = new JTextField(30));
		add(new JLabel("�������  "));
		add(birth = new JTextField(30));
		add(new JLabel("���     "));
		add(etc = new JTextField(90));
		
		signup = new JButton("����");
		add(signup);
		signup.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(name.getText().isEmpty() || age.getText().isEmpty() || phone.getText().isEmpty() || birth.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "��� ������ �Է����ּ���");
				}
				else {
					JOptionPane.showMessageDialog(null, "���Խ�û �Ϸ�");
				}
			}
		});

		setLocationRelativeTo(null);
		setVisible(true);
	}
}

class Test extends JFrame{
	
	LoginWindow loginwin = null;
	SignWindow signwin = null;
	
	void change(String )
	public static void main(String[] args) {
		

	}

}
//���� : http://blog.naver.com/PostView.nhn?blogId=battledocho&logNo=220012083751&categoryNo=67&parentCategoryNo=0&viewDate=&currentPage=1&postListTopCurrentPage=1&from=postView
